import os
import shutil

# ================= 配置 - CẤU HÌNH ĐƯỜNG DẪN =================
# 1. Thư mục chứa 180 tấm ảnh (Tập ảnh mẫu đã chọn trước)
DIR_180_IMGS = r"C:\Users\uytha\Downloads\dataset\val\images"

# 2. Thư mục gốc chứa 900 tấm ảnh và nhãn của bạn
DIR_900_IMGS = r"C:\Users\uytha\Downloads\train python\images"
DIR_900_LABELS = r"C:\Users\uytha\Downloads\train python\du_lieu_da_gan_nhan\labels"  # Để trống "" nếu không có nhãn

# 3. Thư mục kết quả (Nơi chứa ~720 tấm còn lại sau khi lọc)
OUTPUT_DIR = r"C:\Users\uytha\Downloads\dataset\train\images"
# =============================================================

# Tạo thư mục đầu ra chuẩn cấu trúc
out_images = os.path.join(OUTPUT_DIR, "images")
out_labels = os.path.join(OUTPUT_DIR, "labels")
os.makedirs(out_images, exist_ok=True)
if DIR_900_LABELS:
    os.makedirs(out_labels, exist_ok=True)

# Bước 1: Lấy danh sách tên của 180 tấm ảnh (chỉ lấy tên, bỏ đuôi .jpg/.png)
# Dùng set để tốc độ tìm kiếm siêu nhanh
chosen_names = set()
if os.path.exists(DIR_180_IMGS):
    for f in os.listdir(DIR_180_IMGS):
        if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
            base_name = os.path.splitext(f)[0]
            chosen_names.add(base_name)

print(f"📦 Đã ghi nhận danh sách mã của {len(chosen_names)} ảnh đã chọn.")
print("⏳ Đang tiến hành lọc và copy các ảnh còn lại...")

remaining_count = 0

# Bước 2: Quét qua thư mục 900 ảnh, tấm nào KHÔNG NẰM trong 180 tấm thì bốc đi
for img_name in os.listdir(DIR_900_IMGS):
    if img_name.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
        base_name = os.path.splitext(img_name)[0]
        
        # NẾU TÊN FILE KHÔNG NẰM TRONG TẬP 180 -> Đây là ảnh còn lại!
        if base_name not in chosen_names:
            # 1. Copy ảnh sang thư mục mới
            src_img_path = os.path.join(DIR_900_IMGS, img_name)
            shutil.copy(src_img_path, os.path.join(out_images, img_name))
            
            # 2. Copy file nhãn .txt tương ứng sang (nếu có)
            if DIR_900_LABELS:
                txt_name = base_name + ".txt"
                src_txt_path = os.path.join(DIR_900_LABELS, txt_name)
                if os.path.exists(src_txt_path):
                    shutil.copy(src_txt_path, os.path.join(out_labels, txt_name))
            
            remaining_count += 1

print("-" * 50)
print(f"🎉 HOÀN THÀNH XUẤT SẮC!")
print(f"➡️ Đã tách được {remaining_count} tấm ảnh (kèm nhãn) còn lại mà không bị trùng với mục 180 ảnh.")
print(f"📁 Toàn bộ hàng sạch nằm tại: '{OUTPUT_DIR}'")