import os
import shutil

# ================= 配置 - CẤU HÌNH ĐƯỜNG DẪN =================
# 1. Thư mục chứa các file ẢNH sạch mà bạn muốn giữ lại
IMAGE_DIR = r"C:\Users\uytha\Downloads\dataset\val\images"

# 2. Thư mục chứa toàn bộ file LABEL (.txt) gốc (đang bị thừa hoặc lộn xộn)
TOTAL_LABEL_DIR = r"C:\Users\uytha\Downloads\dataset\val\labels"

# 3. Thư mục bạn muốn lưu các file LABEL sau khi đã lọc xong để khớp với ảnh
OUTPUT_LABEL_DIR = r"C:\Users\uytha\Downloads\dataset\val"
# =============================================================

# Tạo thư mục đích nếu chưa có
os.makedirs(OUTPUT_LABEL_DIR, exist_ok=True)

# Định dạng đuôi ảnh được chấp nhận
VALID_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.bmp')

# Lấy danh sách tất cả các file ảnh đang có
image_files = [f for f in os.listdir(IMAGE_DIR) if f.lower().endswith(VALID_EXTENSIONS)]

print("⏳ Đang tiến hành lọc file label theo ảnh...")

count = 0
missing_count = 0

for img_name in image_files:
    # Lấy tên file bỏ đuôi ảnh (Ví dụ: 'person_001.jpg' -> 'person_001')
    base_name = os.path.splitext(img_name)[0]
    
    # Tạo tên file label tương ứng
    label_name = base_name + '.txt'
    
    # Đường dẫn file nhãn gốc và đường dẫn đích
    source_label_path = os.path.join(TOTAL_LABEL_DIR, label_name)
    destination_label_path = os.path.join(OUTPUT_LABEL_DIR, label_name)
    
    # Kiểm tra xem file nhãn đó có tồn tại trong kho nhãn gốc không
    if os.path.exists(source_label_path):
        # Sao chép (hoặc dùng shutil.move nếu muốn di chuyển hẳn)
        shutil.copy(source_label_path, destination_label_path)
        count += 1
    else:
        print(f"⚠️ Cảnh báo: Ảnh {img_name} có tồn tại nhưng KHÔNG tìm thấy file nhãn {label_name}!")
        missing_count += 1

print("-" * 50)
print(f"🎉 Hoàn thành lọc nhãn!")
print(f"✅ Đã tìm thấy và copy {count} file .txt tương ứng khớp với ảnh.")
if missing_count > 0:
    print(f"❌ Có {missing_count} tấm ảnh bị thiếu mất file nhãn (hãy kiểm tra lại).")